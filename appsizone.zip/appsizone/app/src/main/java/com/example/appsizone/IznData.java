package com.example.appsizone;

import java.util.ArrayList;

public class IznData {
    private static String[] iznFullName = {
            "Kwon Eun Bi",
            "Miyawaki Sakura",
            "Kang Hye Won",
            "Choi Ye Na",
            "Lee Chae Yeon",
            "Kim Chae Won",
            "Yabuki Nako",
            "Kim Min Joo",
            "Honda Hitomi",
            "Jo Yu Ri"

    };

    private static String[] iznNickName = {
            "Eun Bi",
            "Sakura",
            "Hye Won",
            "Ye Na",
            "Yeon",
            "Won",
            "Nako",
            "Min Joo",
            "Hitomi",
            "Yu Ri"

    };

    private static String[] iznDetail = {
            "Kwon Eun Bi lebih dikenal dengan nama panggungnya Eun bi, adalah penyanyi, penulis lagu, dan aktor asal Korea Selatan. Ia merupakan anggota dari grup vokal wanita Korea Selatan IZONE",
            "Miyawaki Sakura lebih dikenal sebagai Sakura, adalah seorang penyanyi, penulis lagu, dan produser rekaman. Ia adalah anggota dari grup idola wanita Korea Selatan, Izone ia merilis album solo pertamanya berupa mixtape yang bertajuk Agust D, dengan menggunakan nama Agust D.",
            "Kang Hye Won atau dikenal dengan nama panggung Hye Won adalah seorang penyanyi dan anggota girl band Korea Selatan yaitu Izone. Posisinya adalah main vocalist (vokalis utama), lead dancer (penari), sub-rapper, dan center",
            "Choi Ye Na atau dikenal dengan nama panggung Ye na adalah salah satu anggota Izone yang berasal dari Korea Selatan, dengan posisi vokalis (lead vocal) dan penari utama (main dancer).",
            "Lee Chae Yeon adalah penyanyi dan penulis lagu dari Korea Selatan. Dia adalah member tertua dan vokalis dari girlgrup di Korea Selatan.[3] Sebagai seorang penulis lagu, dia mempunyai lima lagu terakreditasi namanya oleh Korea Music Copyright Association.",
            "Kim Chae Won , adalah seorang idol rapper dan penyanyi sekaligus penulis lagu asal Korea Selatan. Dia adalah pemimpin dan rapper utama dari girl band asal Korea Selatan yaitu Izone, yang dibentuk di bawah naungan Big Hit Entertainment.",
            "Yabuki Nako  lebih dikenal dengan nama \"Nako\", adalah seorang rapper, penari, penyanyi, penulis lagu, dan produser rekaman dari Korea Selatan. Pada tahun 2013, Nako memulai debutnya sebagai anggota girl band dari Korea Selatan Izone, dikelola di bawah Big Hit Entertainment. Sebagai salah satu komposer utama untuk grup, ia memiliki 77 lagu yang terakreditasi atas nama-nya oleh Korea Music Copyright Association.\n" + "Nako merilis mixtape pertamanya, Hope World, di seluruh dunia pada tanggal 1 Maret 2018. Album ini diterima dengan sambutan positif, dan debutnya di peringkat 63 membuatnya menjadi artis solo K-pop tertinggi di Billboard 200.\n",
            "Kim Min Joo, adalah penyanyi, penulis lagu, dan aktor asal Korea Selatan. Ia merupakan anggota dari grup vokal wanita Korea Selatan IZONE\"\n",
            "Honda Hitomi, Menjadi member yang paling galak menurut member lain, dalah penyanyi, penulis lagu, dan aktor asal Korea Selatan. Ia merupakan anggota dari grup vokal wanita Korea Selatan IZONE\"\n",
            "Jo Yu Ri,dalah penyanyi, penulis lagu, dan aktor asal Korea Selatan. Ia merupakan anggota dari grup vokal wanita Korea Selatan IZONE\"\n"

    };

    private static String[] iznLahir = {
            "Yangsan, Korea Selatan, 27 September 1995",
            "Prefektur Kagoshima, Jepang, 19 Maret 1998",
            "Busan, Korea Selatan, 5 Juli 1999",
            "Busan, Korea Selatan, 29 September 1999",
            "Gwacheon, Korea Selatan, 11 Januari 2000",
            "Goyang, Korea Selatan, 1 Agustus 2000",
            "Gwangju, Korea Selatan, 18 Juni 2001",
            "Daegu, Korea Selatan, 5 Februari 2001",
            "Daegu, Korea Selatan, 9 Maret 1993",
            "Busan, Korea Selatan, 1 September 1997"

    };

    private static String[] iznPosisi = {
            "Vokalis",
            "Rapper",
            "Maknae, Vokalis, Rapper",
            "Vokalis",
            "Vokalis, Visual",
            "Leader, Rapper",
            "Rapper",
            "Vokalis",
            "Rapper",
            "Maknae, Vokalis, Rapper"

    };

    private static int[] photo = {
            R.drawable.eunbi,
            R.drawable.sakura,
            R.drawable.hyewon,
            R.drawable.yena,
            R.drawable.yeon,
            R.drawable.honda,
            R.drawable.nako,
            R.drawable.minju,
            R.drawable.wonyoung,
            R.drawable.yujin

    };

    static ArrayList<IznArchitecture> getListData() {
        ArrayList<IznArchitecture> list = new ArrayList<>();
        for (int position = 0; position < iznNickName.length; position++) {
            IznArchitecture nw = new IznArchitecture();
            nw.setFullName(iznFullName[position]);
            nw.setNickName(iznNickName[position]);
            nw.setDetail(iznDetail[position]);
            nw.setLahir(iznLahir[position]);
            nw.setPosisi(iznPosisi[position]);
            nw.setPhoto(photo[position]);
            list.add(nw);
        }

        return list;
    }
}

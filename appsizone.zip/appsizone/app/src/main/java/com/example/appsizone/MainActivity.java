package com.example.appsizone;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rvIzn;
    private ArrayList<IznArchitecture> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvIzn = findViewById(R.id.rv_izn);
        rvIzn.setHasFixedSize(true);

        list.addAll(IznData.getListData());

        showRecyclerList();
    }

    private void showRecyclerList() {
        rvIzn.setLayoutManager(new LinearLayoutManager(this));
        ListIzn listIzn= new ListIzn(list);
        rvIzn.setAdapter(listIzn);

        listIzn.setOnItemClickCallback(new ListIzn.OnItemClickCallback() {
            @Override
            public void onItemClicked(IznArchitecture data) {

                showSelectedData(data);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent about = new Intent(MainActivity.this, datadiri.class);
        startActivity(about);
        return super.onOptionsItemSelected(item);
    }

    public void showSelectedData(IznArchitecture nw) {
        Intent detailIntent = new Intent(MainActivity.this, DetailIzn.class);
        detailIntent.putExtra(DetailIzn.EXTRA_IMG, nw.getPhoto());
        detailIntent.putExtra(DetailIzn.EXTRA_FULLNAME, nw.getFullName());
        detailIntent.putExtra(DetailIzn.EXTRA_NICKNAME, nw.getNickName());
        detailIntent.putExtra(DetailIzn.EXTRA_DETAIL, nw.getDetail());
        detailIntent.putExtra(DetailIzn.EXTRA_LAHIR, nw.getLahir());
        detailIntent.putExtra(DetailIzn.EXTRA_POSISI, nw.getPosisi());
        startActivity(detailIntent);
    }
}

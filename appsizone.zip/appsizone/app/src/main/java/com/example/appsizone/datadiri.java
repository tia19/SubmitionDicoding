package com.example.appsizone;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class datadiri extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_diri);
    }
}
